To play video you will need adobe flash player.
Once installed, open the video on a browser.