*****************************************************************************
*****			     Back to School				*****
*****************************************************************************
*		Game created by: Jackie Chu				    *
*			 	 DJ Dodson				    *
*			 	 Keith Hims				    *
*				 Cagatay Sahin				    *
*									    *
*									    *
* 	To launch the game, double click the BackToSchool.bat file.	    *
* 	It might take few seconds for loading.				    *
*									    *
*	Instructions on how to play the game can be found on the	    *
*	Instructions.pdf file						    *
*									    *
*									    *
*****************************************************************************									    *

	